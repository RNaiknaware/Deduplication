package com;

//import java.io.File;

//import Storage_server.imagecheck;

public class result 
{
	public static void main(String[] args)
	{
/*		
		imagecheck ic=new imagecheck();
		boolean b=false;
		
		File fileone=new File("C:\\Users\\user\\Desktop\\Images\\sign_up_button.png");
		File filetwo=new File("C:\\Users\\user\\Desktop\\Images\\sign_up_button.png");
		b=ic.compareTwoImages(fileone, filetwo);
		if(b==true)
		{
			System.out.println("image matched");
			double p=ic.p;
			System.out.println(p);
		}
		else
		{
			System.out.println("image not matched");
			double pr=ic.pr;
			System.out.println(pr);
		}
	
*/
	}	
}
